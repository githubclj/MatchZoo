import foo.bar

class Foo(object):
    def __init__(self):
        pass
